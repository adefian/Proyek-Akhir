    <div class="container">
      <div class="row">
        <div class="col-lg-7 pt-5 pt-lg-0 order-2 order-lg-1 d-flex align-items-center">
          <div data-aos="zoom-out">
            <h1 class="mt-5 mb-4"> <span>Pick Me Up !</span></h1><h1 style="font-weight:400; font-size:40px">Bersama EcoRanger Pulau Merah</h1>
            <h2>Selamatkan bumi dengan Membuang sampah dengan tepat</h2>
            <div class="text-center text-lg-left mb-5">
              <a href="#features" class="btn-get-started scrollto mr-1">Mulai</a>
              <a href="https://kitabisa.com/campaign/ecoranger" target="_blank" class="btn-get-started scrollto">Donasi</a>
            </div>
          </div>
        </div>
        <div class="col-lg-5 order-1 order-lg-2 hero-img" data-aos="zoom-out" data-aos-delay="300">
          <img src="{{asset('assets-landingpage/img/img02.jpg')}}" class="img-fluid animated" style="border-radius: 30px;" alt="">
        </div>
      </div>
    </div>
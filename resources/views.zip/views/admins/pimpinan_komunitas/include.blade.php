@section('navbar')
    @include('admins.pimpinan_komunitas.navbar')
@endsection

@section('sidebar')
    @include('admins.pimpinan_komunitas.sidebar')
@endsection

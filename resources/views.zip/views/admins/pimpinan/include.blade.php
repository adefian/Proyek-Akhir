@section('navbar')
    @include('admins.pimpinan.navbar')
@endsection

@section('sidebar')
    @include('admins.pimpinan.sidebar')
@endsection

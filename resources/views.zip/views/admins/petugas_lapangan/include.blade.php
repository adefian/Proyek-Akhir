@section('navbar')
    @include('admins.petugas_lapangan.navbar')
@endsection

@section('sidebar')
    @include('admins.petugas_lapangan.sidebar')
@endsection

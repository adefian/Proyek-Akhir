@section('navbar')
    @include('admins.komunitas.navbar')
@endsection

@section('sidebar')
    @include('admins.komunitas.sidebar')
@endsection

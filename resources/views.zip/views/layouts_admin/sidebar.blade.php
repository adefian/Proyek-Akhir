<div class="main-sidebar">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <img style="width: 30%;" src="{{asset('assets/img/pick me up.png')}}" alt="logo">
          </div>
          <div class="sidebar-brand sidebar-brand-sm">
            <img style="width: 50%;" src="{{asset('assets/img/pick me up.png')}}" alt="logo">
          </div>
        
          @yield('sidebar')
          
        </aside>
      </div>
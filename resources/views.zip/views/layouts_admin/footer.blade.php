    <footer class="main-footer">
        <div class="footer-left">
          <!-- Copyright &copy; 2020 <div class="bullet"></div> Design By <a href="github.com/adefian">A F</a> -->
        </div>
        <div class="footer-right">
          1.0.0
        </div>
    </footer>